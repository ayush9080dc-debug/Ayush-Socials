# Tier List Maker

Single-page tier list app. No build step, no dependencies to install.

Features: drag-and-drop ranking, editable tiers (name, color, order), multiple item pools,
bulk add, image items, fullscreen, save (browser localStorage), and export of the tier board
to PNG / JPG / PDF at 2x-4x resolution.

## Run locally
Open `index.html` in a browser.

## Deploy
- Vercel: import the GitHub repo, Framework Preset "Other", no build command.
- Cloudflare Pages: connect the repo, no build command, output directory `/`.
